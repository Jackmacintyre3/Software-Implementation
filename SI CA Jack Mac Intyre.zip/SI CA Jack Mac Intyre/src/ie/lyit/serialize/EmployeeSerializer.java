package ie.lyit.serialize;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JOptionPane;

import ie.lyit.hotel.Employee;

public class EmployeeSerializer {
	private ArrayList<Employee> employees;
	private final String FILE = "employees.bin";
	public EmployeeSerializer() {
		employees = new ArrayList<Employee>();
	}
	public void add() {
		Employee temp = new Employee();
		temp.read();
		employees.add(temp);
	}
	public Employee view() {

			String numberAsString="";
			int empToView=0;
			try {
				
				numberAsString = JOptionPane.showInputDialog(null, "Enter Employee number:");
		        
				empToView = Integer.parseInt(numberAsString);
				
			}
			catch(NumberFormatException nfe) {
				
				JOptionPane.showMessageDialog(null, numberAsString + " is not a valid number.");
				
			}

	        for(Employee tempp: employees) {
	 		   if(tempp.getNumber() == empToView){
	 			  JOptionPane.showMessageDialog(null, tempp);
	 			  return tempp;
	 		   }
		}
		return null;
	}
	public void delete() {
		Employee temp = view();
		
		if(temp != null) {
			employees.remove(temp);
		}
	}
		public void edit() {
			Employee temp = view();
			
			if(temp != null) {
				int number = employees.indexOf(temp);
				temp.read();
				employees.set(number, temp);
			}
		}
			public void serializeEmployee() {
				try {
					FileOutputStream f = new FileOutputStream(FILE);
					ObjectOutputStream o = new ObjectOutputStream(f);
					o.writeObject(employees);
					o.close();
				}
				catch(FileNotFoundException fnfe) {
					System.out.println("File not found");
				}
				catch(IOException e) {
					System.out.println("Cannot write to " + FILE);
				}
				
	}
			public void deserializeEmployee() {
				try {
					FileInputStream f = new FileInputStream(FILE);
					ObjectInputStream o = new ObjectInputStream(f);
					employees = (ArrayList)o.readObject();
					o.close();
				}
				catch(FileNotFoundException fnfe) {
					System.out.println("File not found");
				}
				catch(IOException e) {
					System.out.println("Cannot read from file  " + FILE);
				}
				catch(Exception e) {
					System.out.println("Problem reading file  " + FILE);
				}
				
	}
			public void list() {
				String EmpList = "";
				for(Employee temp : employees) {
					EmpList += temp;
					EmpList += "\n";
				}
				JOptionPane.showMessageDialog(null, EmpList);
			}

}
	
